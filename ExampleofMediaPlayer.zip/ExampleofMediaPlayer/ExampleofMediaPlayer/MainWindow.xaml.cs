﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ExampleofMediaPlayer
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            mycontrol(false);
        }
        private void mycontrol(bool value)
        {
            btnBackward.IsEnabled = value;
            btnForward.IsEnabled = value;
            btnPlay.IsEnabled = value;
            btnStop.IsEnabled = value;
        }
        private void btnBrowse_Click(object sender, RoutedEventArgs e)
        {
            //browse
            Microsoft.Win32.OpenFileDialog ofd = new Microsoft.Win32.OpenFileDialog();
            ofd.Filter = "AVI File|*.avi|WMV File|*.wmv";
            ofd.InitialDirectory = Environment.SpecialFolder.MyDocuments.ToString();
            bool? result= ofd.ShowDialog();
            if(result==true)
            {
                mymedia.Source = new Uri(ofd.FileName);
                mycontrol(true);
            }
            else
            {
                MessageBox.Show("sorry! it is not valid file");
            }
        }

        private void btnPlay_Click(object sender, RoutedEventArgs e)
        {
            if (btnPlay.Content.ToString() == "Play")
            {
                mymedia.Play();
                btnPlay.Content = "Pause";
            }
            else
            {
                mymedia.Pause();
                btnPlay.Content = "Play";
            }
        }

        private void btnStop_Click(object sender, RoutedEventArgs e)
        {
            mymedia.Stop();
        }

        private void btnForward_Click(object sender, RoutedEventArgs e)
        {
            mymedia.Position = mymedia.Position + TimeSpan.FromMinutes(5);
        }

        private void btnBackward_Click(object sender, RoutedEventArgs e)
        {
            mymedia.Position = mymedia.Position - TimeSpan.FromMinutes(5);
        }

        private void btnExit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        private void volumeslider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            mymedia.Volume = e.NewValue;
        }
    }
}
